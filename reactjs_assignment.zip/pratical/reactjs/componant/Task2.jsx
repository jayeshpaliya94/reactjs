import React, { Component } from "react";

class WelcomeMessage extends Component {
  render() {
    return <h1>Welcome to React!</h1>;
  }
}

export default WelcomeMessage;

<WelcomeMessage />
