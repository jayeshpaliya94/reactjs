import React from 'react'

const Welcome = () => {
  return (
    <div>
      <>
      <div>
        <h3>Welcome react frist Task.</h3>
      </div>
      </>
    </div>
  )
}

export default Welcome
